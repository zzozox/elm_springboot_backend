package com.example.elm_springboot_backend.controller;


import com.example.elm_springboot_backend.service.OrderDetailetService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author root
 * @since 2023-09-21
 */
@RestController
@RequestMapping("/orderdetailet")
public class OrderdetailetController {
    @Resource
    OrderDetailetService orderDetailetService;
}

