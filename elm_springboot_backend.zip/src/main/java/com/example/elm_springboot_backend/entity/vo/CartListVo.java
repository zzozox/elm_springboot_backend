package com.example.elm_springboot_backend.entity.vo;

import lombok.Data;

@Data
public class CartListVo {
    private Integer businessId;
    private Integer userId;
}
